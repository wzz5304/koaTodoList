export const ADD = 'ADD'
export const DEL = 'DEL'