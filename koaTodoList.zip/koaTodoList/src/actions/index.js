import * as types from '../constants'

export const getValus = () => ({
    type: types.ADD_TO_CART
  })

export const increase = {
    type: types.ADD
}
export const decrease = {
    type: types.DEL
}